#ifndef _EMPLOYEE_H
#define _EMPLOYEE_H
#include "ArrayList.h"
struct
{
    int id;
    char name[128];
    int horasTrabajadas;
    int sueldo;

}typedef Employee;



/** \brief Muestra un  empleado sin el campo Sueldo
 *
 * \param this puntero a empleado
 */
void employee_print(Employee* this);

/** \brief Muestra todos los empleados sin el campo sueldo
 *
 * \param this puntero a arraylist
 */
void employees_print(ArrayList* this);

/** \brief
 *
 * \param
 * \param
 * \return
 *
 */

Employee* employee_new(void);

/** \brief Setea ID's
 *
 * \param this puntero a empleado
 * \param recibe id como string
 * \return 0 si this y id son != NULL -1 si error.
 *
 */

int employee_setId(Employee* this, char* id);
/** \brief Retorna el valor del id
 *
 * \param this puntero a empleado
 * \return si this != NULL retorna id, caso contrario retorna -1
 *
 */

int employee_getId(Employee* this);

/** \brief setea el nombre del empleado
 *
 * \param this puntero a empleado
 * \param name nombre
 * \return 0 si this y name son != NULL -1 si error.
 *
 */

int employee_setName(Employee* this, char* name);
/** \brief setea las horas trabajadas
 *
 * \param this puntero a empleado
 * \param horas horas
 * \return 0 si this y horas son != NULL -1 si error.
 *
 */

int employee_setHoras(Employee* this, char* horas);
/** \brief Obtiene el nombre del empleado
 *
 * \param this puntero a empleado

 * \return nombre del empleado
 *
 */

char* employee_getName(Employee* this);

/** \brief Muestra un  empleado con el campo Sueldo
 *
 * \param this puntero a empleado
 */

void employee_printSueldo(Employee* this);

/** \brief Muestra todos los empleados con el campo sueldo
 *
 * \param this puntero a arraylist
 */

void employees_printConSueldo(ArrayList* this);
/** \brief obtiene el sueldo de un empleado
 *
 * \param this puntero a empleado
 * \return retorna el valor sueldo
 *
 */

int employee_getSueldo(Employee* this);
/** \brief Setea el sueldo de un empleado
 *
 * \param this puntero a empleado
 * \param sueldo
 * \return 0 si esta OK -1 si error
 *
 */

int employee_setSueldo(Employee* this, char* sueldo);

/** \brief calcula los sueldos de los empleados segun el criterio
 *
 * \param p puntero a void
 */

void calcularSueldo(void* p);



#endif // _EMPLOYEE_H



