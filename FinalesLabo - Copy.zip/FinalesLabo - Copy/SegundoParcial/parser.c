#include <stdio.h>
#include <stdlib.h>
#include "string.h"
#include "ArrayList.h"
#include "Employee.h"


int parserEmployee(FILE* pFile, ArrayList* pArrayListEmployee)
{
    char id[128],name[128],horas[128];

    int fail1,fail2,fail3;
    Employee *emp;

    int cant;
    int returnAux = -1;

    if(pArrayListEmployee != NULL)
    {
        pFile = fopen("data.csv","r");
        if(pFile == NULL)
        {
            printf("Error, no se puede abrir el archivo\n");
        }

        fscanf(pFile, "%[^,] , %[^,], %[^\n] \n",id,name,horas);

        while( !feof(pFile))
        {
            cant =  fscanf(pFile, "%[^,] , %[^,] , %[^\n] \n",id,name,horas);

            if(cant != 3)
            {
                if(feof(pFile))
                {
                    break;
                }
                else
                {
                    printf("No se pudo leer el ultimo registro\n");
                    break;
                }
            }
            emp = employee_new();
            fail1 = employee_setId(emp,id);
            if(fail1 == -1)
            {
                returnAux = -1;
            }
            else
            {
                fail2 = employee_setName(emp,name);
                if(fail2 == -1)
                {
                    returnAux = -1;
                }
                else
                    fail3 = employee_setHoras(emp,horas);
                if(fail3 == -1)
                {
                    returnAux = -1;
                }

                 pArrayListEmployee->add(pArrayListEmployee,emp);

                returnAux = 1;

            }


        }

    }

    fclose(pFile);
    return returnAux;

}




