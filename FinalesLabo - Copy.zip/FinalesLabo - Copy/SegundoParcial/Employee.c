#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "ArrayList.h"
#include "Employee.h"

void calcularSueldo(void* p)
{

    Employee* aux;


    if(p != NULL)
    {
        aux = (Employee*) p;


            if(aux->horasTrabajadas >=1 && aux->horasTrabajadas <=176)
            {
                aux->sueldo = 180*(aux->horasTrabajadas);


            }
            else if(aux->horasTrabajadas>= 177 && aux->horasTrabajadas<= 208)
            {
                aux->sueldo = 270*(aux->horasTrabajadas);



            }
            else if(aux->horasTrabajadas>= 209 && aux->horasTrabajadas <= 240)
            {
                aux->sueldo = 360*(aux->horasTrabajadas);


            }



    }



}


void employees_print(ArrayList* this)
{
    int i;

    printf("ID\tNOMBRE\tHORAS\n");

    for(i=0; i<this->len(this)-800; i++)
    {
        employee_print(this->get(this,i));

    }
    printf("Presione una tecla para continuar con el parseo\n");
    system("pause");
    for(i=this->len(this)-800; i<this->len(this); i++)
    {
        employee_print(this->get(this,i));

    }

}


void employees_printConSueldo(ArrayList* this)
{
    int i;

    printf("ID\tNOMBRE\tHORAS\tSUELDO\n");

    for(i=0; i<this->len(this)-800; i++)
    {
        employee_printSueldo(this->get(this,i));

    }
    printf("Presione una tecla para continuar con el parseo\n");
    system("pause");
    for(i=this->len(this)-800; i<this->len(this); i++)
    {
        employee_printSueldo(this->get(this,i));

    }

}


Employee* employee_new(void)
{
    Employee* returnAux = (Employee*) malloc(sizeof(Employee));

    return returnAux;
}



//SET ID

int employee_setId(Employee* this, char* id)
{
    int retorno = -1;
    int aux;
    if(this != NULL && id !=NULL)
    {
        aux = atoi(id);
        this->id = aux;
        retorno = 0;
    }


    return retorno;

}
//GET ID
int employee_getId(Employee* this)
{
    int retorno= -1;
    if(this != NULL)
    {
        retorno = this->id;
    }
    return retorno;

}
//SET NAME
int employee_setName(Employee* this, char* name)
{
    int returnAux = -1;
    int len;


    if(this != NULL && name != NULL)
    {

        len = strlen(name);
        if(len >127)
        {
            printf("Error\n");
            exit(1);
        }
        else
        {

            strcpy(this->name, name);
        }

        returnAux = 0;

    }

    return returnAux;

}
//GET NAME
char* employee_getName(Employee* this)
{
    char* retorno;

    if(this != NULL)
    {
        retorno = this->name;
    }

    return retorno;


}

int employee_setHoras(Employee* this, char* horas)
{
    int retorno = -1;
    int aux;
    if(this != NULL && horas !=NULL)
    {
        aux = atoi(horas);
        this->horasTrabajadas = aux;
        retorno = 0;
    }


    return retorno;

}
int employee_getHoras(Employee* this)
{
    int retorno= -1;
    if(this != NULL)
    {
        retorno = this->horasTrabajadas;
    }
    return retorno;

}

int employee_setSueldo(Employee* this, char* sueldo)
{
    int retorno = -1;
    int aux;
    if(this != NULL && sueldo !=NULL)
    {
        aux = atoi(sueldo);
        this->sueldo = aux;
        retorno = 0;
    }


    return retorno;

}

int employee_getSueldo(Employee* this)
{
    int retorno= -1;
    if(this != NULL)
    {
        retorno = this->sueldo;
    }
    return retorno;

}

void employee_print(Employee* this)
{
    if(this !=NULL)
    {
        printf("%4d\t %16s\t%4d\n",employee_getId(this), employee_getName(this), employee_getHoras(this));
    }

}

void employee_printSueldo(Employee* this)
{
    if(this !=NULL)
    {
        printf("%4d\t %16s\t%4d\t%4d\n",employee_getId(this), employee_getName(this), employee_getHoras(this),employee_getSueldo(this));
    }

}


int generarArchivoSueldos(char* fileName,ArrayList* this)
{
    FILE* f;

    Employee* actual= employee_new();


    int returnAux = -1;
    int i;

    if(this != NULL)
    {
        f = fopen(fileName, "w");
        if(f != NULL)
        {
            fprintf(f,"id,name,horas,sueldo\n");
            for(i=0; i<this->len(this); i++)
            {

                actual = this->get(this,i);


                fprintf(f,"%d, %s, %d, $%d\n",actual->id,actual->name,actual->horasTrabajadas,actual->sueldo);

            }



            fclose(f);

        }
        returnAux = 1;
    }

    return returnAux;

}


