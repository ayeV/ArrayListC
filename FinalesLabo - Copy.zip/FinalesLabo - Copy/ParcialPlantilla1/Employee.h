#ifndef _EMPLOYEE_H
#define _EMPLOYEE_H
struct
{
    int id;
    char name[51];
    char lastName[51];
    int isEmpty;

}typedef Employee;


/** \brief Compara los empleados por nombre
 *
 * \param  pEmployeeA puntero a void
 * \param  pEmployeeB puntero a void
 * \return 1 si pEmployeeA->name> pEmployeeB->name, 0 en el caso contrario
 *
 */

int employee_compare(void* pEmployeeA,void* pEmployeeB);
/** \brief Muestra un  empleado
 *
 * \param this puntero a empleado
 */

void employee_print(Employee* this);
/** \brief Muestra todos los empleados
 *
 * \param this puntero a arraylist
 */
void employees_print(ArrayList* this);

Employee* employee_new(void);
/** \brief Elimina un empleado por ID
 *
 * \param this puntero a empleado

 */

void employee_delete(Employee* this);
/** \brief Setea ID's
 *
 * \param this puntero a empleado
 * \param recibe id como string
 * \return 0 si this y id son != NULL -1 si error.
 *
 */

int employee_setId(Employee* this, char* id);
/** \brief Retorna el valor del id
 *
 * \param this puntero a empleado
 * \return si this != NULL retorna id, caso contrario retorna -1
 *
 */

int employee_getId(Employee* this);

int employee_setName(Employee* this, char* name);
char* employee_getName(Employee* this);


int employee_setLastName(Employee* this, char* lastName);
char* employee_getlastName(Employee* this);


void cargarEmpleado(ArrayList* this);
void listarEmpleadosDesdeHasta(ArrayList* this, Employee* emp);

int guardarArchivo(ArrayList* this);
void deleteEmployee(ArrayList* this, Employee* emp);





#endif // _EMPLOYEE_H



