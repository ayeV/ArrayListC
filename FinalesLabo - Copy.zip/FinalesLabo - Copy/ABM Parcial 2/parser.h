#ifndef PARSER_H_INCLUDED
#define PARSER_H_INCLUDED

#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <string.h>
#include <ctype.h>

int parserEmployee(ArrayList* pArrayListEmployee);

#endif // PARSER_H_INCLUDED

