#ifndef _USERS_H
#define _USERS_H
#include "ArrayList.h"
struct
{

    char nick[128];
    int followers;
    int idUsuario;

}typedef eUser;

eUser* user_new(void);
int user_setNick(eUser* this, char* nick);
char* user_getNick(eUser* this);
int user_setFollowers(eUser* this, char* followers);
int user_getFollowers(eUser* this);
int user_setIdUsuario(eUser* this, char* idUsuario);
int user_getIdUsuario(eUser* this);
void user_print(eUser* this);
void users_print(ArrayList* this);






#endif // _USERS_H



