#include <stdio.h>
#include <stdlib.h>
#include "ArrayList.h"
#include "Parser.h"
#include "post.h"
#include "users.h"
#include "feed.h"



int main()
{

    char seguir = 's';

    int opcion = 0;
    ArrayList* listaPost;
    ArrayList* listaUsers;
    ArrayList* feed;
    FILE* pArch;


    listaPost = al_newArrayList();
    listaUsers = al_newArrayList();
    feed = al_newArrayList();

    while(seguir=='s')
    {
        printf("1-Parse del archivo usuarios.csv \n");
        printf("2-Parse del archivo mensajes.csv \n");

        printf("3-Generar archivo feed.csv\n");
        printf("4- Salir\n");

        scanf("%d",&opcion);


        switch(opcion)
        {
        case 1:
            if(parserUsers(pArch,listaUsers) == 1)
            {
                printf("Parser exitoso\n");
                printf("--LISTADO--\n");


                users_print(listaUsers);

            }
            else
            {
                printf("No se pudo parsear\n");
            }
            system("pause");

            break;

        case 2:

            if(parserPost(pArch,listaPost) == 1)
            {
                printf("Parser exitoso\n");
                printf("--LISTADO--\n");


                posts_print(listaPost);

            }
            else
            {
                printf("No se pudo parsear\n");
            }
            system("pause");

            break;
        case 3:
            if(crearFeed(listaUsers,listaPost,feed) == 1)
            {
                feed->sort(feed,compareFeeds,0);
                if(generarArchivo("feed.csv",feed) == 1 )
            {
                printf("Archivo generado con exito\n");
                printf("LISTADO\n");


            }
            else
            {
                printf("Error al generar el archivo\n");
            }


            }
            else
            {
                printf("Ha ocurrido un error\n");
            }


            system("pause");
            break;

        case 4:
            seguir = 'n';
            system("pause");
            break;
        default:
            printf("Opcion invalida\n");
            system("pause");
            break;
        }
    }


    return 0;
}

