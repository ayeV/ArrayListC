#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "ArrayList.h"
#include "post.h"
#include "users.h"
ePost* post_new(void)
{
    ePost* returnAux = (ePost*) malloc(sizeof(ePost));

    return returnAux;
}



//SET ID MENSAJE

int post_setIdMensaje(ePost* this, char* idMensaje)
{
    int retorno = -1;
    int aux;
    if(this != NULL && idMensaje !=NULL)
    {
        aux = atoi(idMensaje);
        this->idMensaje = aux;
        retorno = 0;
    }


    return retorno;

}
//GET ID MENSAJE
int post_getIdMensaje(ePost* this)
{
    int retorno= -1;
    if(this != NULL)
    {
        retorno = this->idMensaje;
    }
    return retorno;

}
//SET Mensaje
int post_setMensaje(ePost* this, char* mensaje)
{
    int returnAux = -1;
    int len;


    if(this != NULL && mensaje != NULL)
    {

        len = strlen(mensaje);
        if(len >2000)
        {
            printf("Error\n");

        }
        else
        {

            strcpy(this->mensaje, mensaje);
        }

        returnAux = 0;

    }

    return returnAux;

}
//GET MENSAJE
char* post_getMensaje(ePost* this)
{
    char* retorno;

    if(this != NULL)
    {
        retorno = this->mensaje;
    }

    return retorno;


}

int post_setLikes(ePost* this, char* likes)
{
    int retorno = -1;
    int aux;
    if(this != NULL && likes !=NULL)
    {
        aux = atoi(likes);
        this->likes = aux;
        retorno = 0;
    }


    return retorno;

}

int post_getLikes(ePost* this)
{
    int retorno= -1;
    if(this != NULL)
    {
        retorno = this->likes;
    }
    return retorno;

}

int post_setIdUsuario(ePost* this, char* idUsuario)
{
    int retorno = -1;
    int aux;
    if(this != NULL && idUsuario !=NULL)
    {
        aux = atoi(idUsuario);
        this->idUsuario = aux;
        retorno = 0;
    }


    return retorno;

}

int post_getIdUsuario(ePost* this)
{
    int retorno= -1;
    if(this != NULL)
    {
        retorno = this->idUsuario;
    }
    return retorno;

}

void post_print(ePost* this)
{
    if(this !=NULL)
    {
        printf("%4d\t %4d\t%4d\t%24s\n",post_getIdMensaje(this), post_getIdUsuario(this), post_getLikes(this),post_getMensaje(this));
    }

}

void posts_print(ArrayList* this)
{
    int i;

    printf("ID MENSAJE\tID USUARIO \t\tLIKES\tMENSAJE\n");

    for(i=0; i<this->len(this); i++)
    {
        post_print(this->get(this,i));

    }


}

void feed_print(ePost* this1, eUser* this2)
{
    if(this1 !=NULL && this2 != NULL)
    {
        printf("%4d \t %24s \t %4d \t %4d \t %24s \n",post_getIdMensaje(this1), post_getMensaje(this1), post_getLikes(this1),user_getIdUsuario(this2), user_getNick(this2),user_getFollowers(this2));
    }

}


