#ifndef _POST_H
#define _POST_H
#include "ArrayList.h"
struct
{
    int idMensaje;
    char mensaje[2000];
    int likes;
    int idUsuario;

}typedef ePost;


ePost* post_new(void);
int post_setIdMensaje(ePost* this, char* idMensaje);
int post_getIdMensaje(ePost* this);
int post_setMensaje(ePost* this, char* mensaje);
char* post_getMensaje(ePost* this);
int post_setLikes(ePost* this, char* likes);
int post_getLikes(ePost* this);
int post_setIdUsuario(ePost* this, char* idUsuario);
int post_getIdUsuario(ePost* this);
void post_print(ePost* this);
void posts_print(ArrayList* this);



#endif // _POST_H




