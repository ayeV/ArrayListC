#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "ArrayList.h"
#include "post.h"
#include "users.h"
#include "feed.h"

eFeed* feed_new(void)
{
    eFeed* returnAux = (eFeed*) malloc(sizeof(eFeed));

    return returnAux;
}



//SET ID MENSAJE

int feed_setIdMensaje(eFeed* this, int idMensaje)
{
    int retorno = -1;

    if(this != NULL && idMensaje >0)
    {

        this->idMensaje = idMensaje;
        retorno = 0;
    }


    return retorno;

}
//GET ID MENSAJE
int feed_getIdMensaje(eFeed* this)
{
    int retorno= -1;
    if(this != NULL)
    {
        retorno = this->idMensaje;
    }
    return retorno;

}
//SET Mensaje
int feed_setMensaje(eFeed* this, char* mensaje)
{
    int returnAux = -1;
    int len;


    if(this != NULL && mensaje != NULL)
    {

        len = strlen(mensaje);
        if(len >2000)
        {
            printf("Error\n");

        }
        else
        {

            strcpy(this->mensaje, mensaje);
        }

        returnAux = 0;

    }

    return returnAux;

}
//GET MENSAJE
char* feed_getMensaje(eFeed* this)
{
    char* retorno;

    if(this != NULL)
    {
        retorno = this->mensaje;
    }

    return retorno;


}

int feed_setLikes(eFeed* this, int likes)
{
    int retorno = -1;

    if(this != NULL && likes >= 0)
    {

        this->likes = likes;
        retorno = 0;
    }


    return retorno;

}

int feed_getLikes(eFeed* this)
{
    int retorno= -1;
    if(this != NULL)
    {
        retorno = this->likes;
    }
    return retorno;

}

int feed_setIdUser(eFeed* this, int idUsuario)
{
    int retorno = -1;

    if(this != NULL && idUsuario > 0)
    {

        this->idUser = idUsuario;
        retorno = 0;
    }


    return retorno;

}

int feed_getIdUser(eFeed* this)
{
    int retorno= -1;
    if(this != NULL)
    {
        retorno = this->idUser;
    }
    return retorno;

}

int feed_setNick(eFeed* this, char* nick)
{
    int returnAux = -1;
    int len;


    if(this != NULL && nick != NULL)
    {

        len = strlen(nick);
        if(len >128)
        {
            printf("Error\n");

        }
        else
        {

            strcpy(this->nick, nick);
        }

        returnAux = 0;

    }

    return returnAux;

}
//GET NICK
char* feed_getNick(eFeed* this)
{
    char* retorno;

    if(this != NULL)
    {
        retorno = this->nick;
    }

    return retorno;


}

int feed_setFollowers(eFeed* this, int followers)
{
    int retorno = -1;

    if(this != NULL && followers >= 0)
    {

        this->followers = followers;
        retorno = 0;
    }


    return retorno;

}

int feed_getFollowers(eFeed* this)
{
    int retorno= -1;
    if(this != NULL)
    {
        retorno = this->followers;
    }
    return retorno;

}

int crearFeed(ArrayList *pUsuarios, ArrayList *pMensajes, ArrayList *pFeeds)
{
    int i,j;
    ePost *post = post_new();
    eUser *user = user_new();
    eFeed *aux;


    int returnAux = -1;

    if(pUsuarios != NULL && pMensajes != NULL && pFeeds != NULL)
    {


        for (i=0 ; i<pMensajes->len(pMensajes) ; i++)
        {
            post = pMensajes->get(pMensajes,i);

                for (j=0 ; j<pUsuarios->len(pUsuarios) ; j++)
                {
                    user = pUsuarios->get(pUsuarios,j);

                    if(post->idUsuario == user->idUsuario)
                    {
                        aux = feed_new();

                        feed_setIdMensaje(aux,post->idMensaje);
                        feed_setMensaje(aux,post->mensaje);
                        feed_setLikes(aux,post->likes);
                        feed_setIdUser(aux,user->idUsuario);
                        feed_setNick(aux,user->nick);
                        feed_setFollowers(aux,user->followers);


                        pFeeds->add(pFeeds,aux);
                    }
                }
        }
        returnAux = 1;
    }

    return returnAux;
}






int generarArchivo(char* path, ArrayList* this)
{
    FILE* f;


    eFeed* aux;
    aux = feed_new();

    int returnAux = -1;
    int i;

    if(this != NULL)
    {
        f = fopen(path, "w");
        if(f != NULL)
        {
            fprintf(f,"ID MENSAJE, MENSAJE, LIKES ,ID USUARIO, NICK, FOLLOWERS\n");
            for(i=0; i<this->len(this); i++)
            {

                aux = this->get(this,i);




                fprintf(f,"%d, %s, %d,%d, %s, %d\n",feed_getIdMensaje(aux),feed_getMensaje(aux),feed_getLikes(aux),feed_getIdUser(aux),feed_getNick(aux),feed_getFollowers(aux));

            }



            fclose(f);

        }
        returnAux = 1;
    }

    return returnAux;




}

int compareFeeds(void *A, void *B)
{
    int returnAux= 0;
    eFeed* auxA;
    eFeed* auxB;

    if( A != NULL && B != NULL)
    {
        auxA = (eFeed*)A;
        auxB = (eFeed*)B;

        if(auxA->followers > auxB->followers)
        {
            returnAux = 1;
        }
        else if(auxA->followers < auxB->followers)
        {
            returnAux = -1;
        }
         else  if(auxA->followers == auxB->followers)
            {
                if(auxA->likes > auxB->likes)
                {
                    returnAux = 1;
                }
                else if( auxA->likes < auxB->likes)
                {
                    returnAux = -1;
                }
            }
        }


    return returnAux;
}
