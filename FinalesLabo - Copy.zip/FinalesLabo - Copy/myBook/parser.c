#include <stdio.h>
#include <stdlib.h>
#include "string.h"
#include "ArrayList.h"
#include "post.h"
#include "users.h"

int parserPost(FILE* pFile, ArrayList* pArrayListPost)
{
    char idMensaje[120],mensaje[2000],likes[120],idUsuario[120];

    int fail1,fail2,fail3,fail4;
    ePost *post;

    int cant;
    int returnAux = -1;

    if(pArrayListPost != NULL)
    {
        pFile = fopen("mensajes.csv","r");
        if(pFile == NULL)
        {
            printf("Error, no se puede abrir el archivo\n");
        }

        fscanf(pFile, "%[^,] , %[^,], %[^,] , %[^\n] \n",idMensaje,idUsuario,likes,mensaje);

        while( !feof(pFile))
        {
            cant =   fscanf(pFile, "%[^,] , %[^,] , %[^,] , %[^\n] \n",idMensaje,idUsuario,likes,mensaje);

            if(cant != 4)
            {
                if(feof(pFile))
                {
                    break;
                }
                else
                {
                    printf("No se pudo leer el ultimo registro\n");
                    break;
                }
            }
            post = post_new();
            fail1 = post_setIdMensaje(post,idMensaje);
            if(fail1 == -1)
            {
                returnAux = -1;
            }
            else
            {
                fail2 = post_setIdUsuario(post,idUsuario);
                if(fail2 == -1)
                {
                    returnAux = -1;
                }
                else
                    fail3 = post_setLikes(post,likes);
                if(fail3 == -1)
                {
                    returnAux = -1;
                }
                else
                    fail4 = post_setMensaje(post,mensaje);
                if(fail4 == -1)
                {
                    returnAux = -1;
                }

                 pArrayListPost->add(pArrayListPost,post);

                returnAux = 1;

            }


        }

    }

    fclose(pFile);
    return returnAux;

}


int parserUsers(FILE* pFile, ArrayList* pList)
{
    char nick[128],followers[128],idUsuario[128];

    int fail1,fail2,fail3;
    eUser *user;

    int cant;
    int returnAux = -1;

    if(pList != NULL)
    {
        pFile = fopen("usuarios.csv","r");
        if(pFile == NULL)
        {
            printf("Error, no se puede abrir el archivo\n");
        }

        fscanf(pFile, "%[^,] , %[^,], %[^\n] \n",idUsuario,nick,followers);

        while( !feof(pFile))
        {
            cant =    fscanf(pFile, "%[^,] , %[^,], %[^\n] \n",idUsuario,nick,followers);

            if(cant != 3)
            {
                if(feof(pFile))
                {
                    break;
                }
                else
                {
                    printf("No se pudo leer el ultimo registro\n");
                    break;
                }
            }
            user = user_new();
            fail1 = user_setIdUsuario(user,idUsuario);
            if(fail1 == -1)
            {
                returnAux = -1;
            }
            else
            {
                fail2 = user_setNick(user,nick);
                if(fail2 == -1)
                {
                    returnAux = -1;
                }
                else
                    fail3 = user_setFollowers(user,followers);
                if(fail3 == -1)
                {
                    returnAux = -1;
                }


                 pList->add(pList,user);

                returnAux = 1;

            }


        }

    }

    fclose(pFile);
    return returnAux;

}




