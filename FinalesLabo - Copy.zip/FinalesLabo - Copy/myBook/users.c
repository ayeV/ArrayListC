#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "ArrayList.h"
#include "users.h"

eUser* user_new(void)
{
    eUser* returnAux = (eUser*) malloc(sizeof(eUser));

    return returnAux;
}




//SET nick
int user_setNick(eUser* this, char* nick)
{
    int returnAux = -1;
    int len;


    if(this != NULL && nick != NULL)
    {

        len = strlen(nick);
        if(len >128)
        {
            printf("Error\n");

        }
        else
        {

            strcpy(this->nick, nick);
        }

        returnAux = 0;

    }

    return returnAux;

}
//GET NICK
char* user_getNick(eUser* this)
{
    char* retorno;

    if(this != NULL)
    {
        retorno = this->nick;
    }

    return retorno;


}

int user_setFollowers(eUser* this, char* followers)
{
    int retorno = -1;
    int aux;
    if(this != NULL && followers !=NULL)
    {
        aux = atoi(followers);
        this->followers = aux;
        retorno = 0;
    }


    return retorno;

}

int user_getFollowers(eUser* this)
{
    int retorno= -1;
    if(this != NULL)
    {
        retorno = this->followers;
    }
    return retorno;

}

int user_setIdUsuario(eUser* this, char* idUsuario)
{
    int retorno = -1;
    int aux;
    if(this != NULL && idUsuario !=NULL)
    {
        aux = atoi(idUsuario);
        this->idUsuario = aux;
        retorno = 0;
    }


    return retorno;

}

int user_getIdUsuario(eUser* this)
{
    int retorno= -1;
    if(this != NULL)
    {
        retorno = this->idUsuario;
    }
    return retorno;

}

void user_print(eUser* this)
{
    if(this !=NULL)
    {
        printf("%4d\t %16s\t%4d\n",user_getIdUsuario(this),user_getNick(this),user_getFollowers(this));
    }

}

void users_print(ArrayList* this)
{
    int i;

    printf("ID USUARIO\tNICK \tFOLLOWERS\n");

    for(i=0; i<this->len(this); i++)
    {
       user_print(this->get(this,i));

    }


}

