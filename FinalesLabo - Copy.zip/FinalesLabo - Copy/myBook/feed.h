#ifndef _FEED_H
#define _FEED_H
#include "ArrayList.h"
#include "post.h"
#include "users.h"
struct
{
    int idUser;
    int followers;
    char nick[128];
    char mensaje[2000];
    int idMensaje;
    int likes;

}typedef eFeed;


int feed_setIdMensaje(eFeed* this, int idMensaje);
int compareFeeds(void *A, void *B);




#endif // _FEED_H





