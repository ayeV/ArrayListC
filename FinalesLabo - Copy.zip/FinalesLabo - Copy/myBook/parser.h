int parserPost(FILE* pFile, ArrayList* pArrayListPost);
int parserUsers(FILE* pFile, ArrayList* pList);
