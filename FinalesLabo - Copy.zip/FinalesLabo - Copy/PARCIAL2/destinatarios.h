#ifndef __DESTINATARIOS_H_INCLUDED
#define __DESTINATARIOS_H_INLUDED
#include <stdio.h>
#include <stdlib.h>

#include "ArrayList.h"
#include "input.h"
typedef struct
{
    char name[51];
    char email[51];

} eDestinatario;

/** \brief Setea el nombre del destinatario
 *
 * \param this puntero a destinatario
 * \param name nombre
 * \return -1 si error, 0 si OK
 *
 */

int destinatario_setName(eDestinatario* this, char* name);

/** \brief Obtiene el nombre del destinatario
 *
 * \param this puntero a destinatario
 * \return devuelve el nombre
 *
 */

char* destinatario_getName(eDestinatario* this);

/** \brief Setea el email del destinatario
 *
 * \param this puntero a destinatario
 * \param email email
 * \return -1 si error, 0 si OK
 *
 */

int destinatario_setEmail(eDestinatario* this, char* email);
/** \brief Obtiene el email del destinatario
 *
 * \param this puntero a destinatario
 * \return devuelve el email
 *
 */

char* destinatario_getEmail(eDestinatario* this);
/** \brief
 *
 * \param
 * \param
 * \return
 *
 */

eDestinatario* destinatario_new(void);
/** \brief
 *
 * \param
 * \param
 * \return
 *
 */

void destinatario_print(eDestinatario* this);
/** \brief
 *
 * \param
 * \param
 * \return
 *
 */

void destinatarios_print(ArrayList* this);
/** \brief
 *
 * \param
 * \param
 * \return
 *
 */

int destinatario_compareMail(void* pDestA,void* pDestB);
/** \brief
 *
 * \param
 * \param
 * \return
 *
 */

int  destinatario_depuracion(ArrayList* this, ArrayList* blackList);
/** \brief
 *
 * \param
 * \param
 * \return
 *
 */

int  destinatario_borrarRepetidosDeArrayList(ArrayList* this);
/** \brief
 *
 * \param
 * \param
 * \return
 *
 */

int generarArchivo(char* path, ArrayList* this);






#endif // DESTINATARIOS_H_INCLUDED
