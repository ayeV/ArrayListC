#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "ArrayList.h"
#include "input.h"
#include "destinatarios.h"


int main()
{
    int opcion = 0;
    char seguir = 's';
    char guardar= 's';

    char path[51];




    ArrayList* listaDest;
    ArrayList* blackList;

    ArrayList* listaFinal;

    FILE *pArch;

    listaDest = al_newArrayList();
    blackList = al_newArrayList();

    listaFinal = al_newArrayList();
    while(seguir=='s')
    {
        printf("1-Cargar destinatarios (destinatarios.csv) \n");
        printf("2-Cargar lista negra\n");
        printf("3-Depurar\n");
        printf("4-Listar\n");
        printf("5- Salir\n");

        scanf("%d",&opcion);


        switch(opcion)
        {
        case 1:
            getString(path,"Ingrese el nombre del archivo a cargar: ","Error, ingrese nombre valido: ",2,50);
            strlwr(path);
            if( (strcmp(path,"destinatarios.csv")) == 0)
            {
                if(  parserDestinatarios(pArch,listaDest,path) == 0)
                {
                    printf("Parser exitoso\n");
                    printf("--LISTADO--\n");
                    destinatarios_print(listaDest);
                }
                else
                {
                    printf("error\n");
                }
            }
            else
            {
                printf("No ha ingresado correctamente el nombre del archivo\n");
            }




            system("pause");

            break;
        case 2:
            getString(path,"Ingrese el nombre del archivo a cargar: ","Error, ingrese nombre valido: ",2,50);
            strlwr(path);
            if( strcmp(path,"black_list.csv") == 0 )
            {
                if(  parserDestinatarios(pArch,blackList,path) == 0)
                {
                    printf("Parser exitoso\n");
                    printf("--LISTADO--\n");
                   destinatarios_print(blackList);

                }
                else
                {
                    printf("error\n");
                }
            }
            else
            {
                printf("No ha ingresado correctamente el nombre del archivo\n");
            }


            system("pause");
            break;
        case 3:
             if(!destinatario_depuracion(listaDest,blackList))//si devuelve 0 entra!
            {
                if(!destinatario_borrarRepetidosDeArrayList(listaDest))//si devuelve 0 entra
                {
                    printf("Depuracion exitosa\n");
                }
                else
                    printf("Error al borrar\n");
            }
            else
                printf("Error al depurar\n");

            system("pause");
            break;
        case 4:
            destinatarios_print(listaDest);

            system("pause");
            break;

        case 5:
              printf("\nGuardar cambios S/N ?: \n");
            guardar = tolower(getche());

            if(guardar == 's')
            {
              if(generarArchivo("finalList.csv",listaFinal) == 0 )
                {
                    printf("Archivo guardado con exito\n");
                }
                else
                {
                  printf("Error al guardar el archivo\n");
                }

              }
              else
              {
                  printf("Ha cancelado guardar\n");
              }


            seguir = 'n';
            system("pause");
            break;
        default:
            printf("Opcion invalida\n");
            system("pause");
            break;
        }
    }







    return 0;
}
