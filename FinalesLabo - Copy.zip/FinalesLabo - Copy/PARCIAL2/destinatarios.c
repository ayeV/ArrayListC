#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "ArrayList.h"
#include "input.h"
#include "destinatarios.h"

int destinatario_setName(eDestinatario* this, char* name)
{
    int returnAux = -1;
    int len;


    if(this != NULL && name != NULL)
    {

        len = strlen(name);
        if(len >50)
        {
            printf("Error\n");
            exit(1);
        }
        else
        {

            strcpy(this->name, name);
        }

        returnAux = 0;

    }

    return returnAux;

}
//GET NAME
char* destinatario_getName(eDestinatario* this)
{
    char* retorno;

    if(this != NULL)
    {
        retorno = this->name;
    }

    return retorno;


}


int destinatario_setEmail(eDestinatario* this, char* email)
{
    int returnAux = -1;
    int len;


    if(this != NULL && email != NULL)
    {

        len = strlen(email);
        if(len >50)
        {
            printf("Error\n");
            exit(1);
        }
        else
        {

            strcpy(this->email, email);
        }

        returnAux = 0;

    }

    return returnAux;

}
//GET NAME
char* destinatario_getEmail(eDestinatario* this)
{
    char* retorno;

    if(this != NULL)
    {
        retorno = this->email;
    }

    return retorno;


}

eDestinatario* destinatario_new(void)
{
    eDestinatario* returnAux = (eDestinatario*) malloc(sizeof(eDestinatario));

    return returnAux;
}

void destinatario_print(eDestinatario* this)
{
    if(this !=NULL)
    {
        printf("%16s\t %16s\n",destinatario_getName(this), destinatario_getEmail(this));
    }

}




void destinatarios_print(ArrayList* this)
{
    int i;
    for(i=0;i<this->len(this);i++)
    {


            destinatario_print(this->get(this,i));


    }
}

int destinatario_compareMail(void* pDestA,void* pDestB)
{
    eDestinatario* destinatarioA=(eDestinatario*)pDestA;
    eDestinatario* destinatarioB=(eDestinatario*)pDestB;
    char mailA[51];
    char mailB[51];
    int retorno = 0;
    if(destinatarioA!=NULL && destinatarioB != NULL)
    {
        destinatario_getEmail(destinatarioA);
        destinatario_getEmail(destinatarioB);
        retorno = strcmp(mailA,mailB);
        if(retorno>0)
        {
            retorno=-1;
        }
        else if(retorno<0)
        {
            retorno=1;
        }
    }
    return retorno ;

}

int  destinatario_depuracion(ArrayList* this, ArrayList* blackList)
{
    eDestinatario* aux;
    int i;
    int retorno=-1;
    for(i=0; i<blackList->len(blackList); i++) //iteremos la misma cantidad de veces, que de clientes halla en la blacklist.
    {
        aux= blackList->get(blackList,i);//obtenemos la direccion de memoria del elemento en la poscicion i
        int index = this->indexOf(this,aux,destinatario_compareMail);//cargamos a index con el valor que retorna la funcion. devuelve indice si hay coincidencia, sino devuelve -1
        this->remove(this,index);//si el indice es valido lo elimina, si es -1 no hace nada.
        retorno =0;

    }
    return retorno;
}

int  destinatario_borrarRepetidosDeArrayList(ArrayList* this)
{
    int i;
    int retorno=-1;
    if(this!=NULL)
    {
        retorno=0;
        for(i=0; i<this->len(this)-1; i++)
        {
            eDestinatario* auxiliar=this->get(this,i);
            eDestinatario* auxiliar2=this->get(this,i+1);
            if((strcmp(auxiliar->name,auxiliar2->name)==0) && (strcmp(auxiliar->email,auxiliar2->email)==0))
            {
                this->remove(this,i);
            }

        }

    }
    return retorno;
}


int generarArchivo(char* path, ArrayList* this)
{
    int retorno = -1;
    int i;
    char nombre[128];
    char mail[128];
    eDestinatario* aux;

    if(path != NULL && this != NULL)
    {
        FILE* fp = fopen(path, "w");

        if(fp != NULL)
        {
            for(i = 0; i < this->len(this); i++)
            {
                aux = this->get(this, i);
                destinatario_getName(aux);
                destinatario_getEmail(aux);
                fprintf(fp, "%s - %s\n", nombre, mail);
            }
            retorno = 0;
            fclose(fp);
        }
    }
    return retorno;
}
