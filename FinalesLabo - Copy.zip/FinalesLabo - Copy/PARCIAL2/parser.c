#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "ArrayList.h"
#include "input.h"
#include "destinatarios.h"




int parserDestinatarios(FILE* pFile, ArrayList* pList,char* path)
{
    char name[128],email[128];
    int fail1,fail2;
    eDestinatario* dest;

    int cant;
    int returnAux = -1;

    if(pList != NULL)
    {
        pFile = fopen(path,"r");
        if(pFile == NULL)
        {
            printf("Error, no se puede abrir el archivo\n");
        }

        fscanf(pFile, "%[^,] , %[^\n] \n",name,email);

        while( !feof(pFile))
        {
            cant =  fscanf(pFile, "%[^,] ,%[^\n] \n",name,email);

            if(cant != 2)
            {
                if(feof(pFile))
                {
                    break;
                }
                else
                {
                    printf("No se pudo leer el ultimo registro\n");
                    break;
                }
            }
            dest = destinatario_new();
            fail1 = destinatario_setName(dest,name);
            if(fail1 == -1)
            {
                returnAux = -1;
            }
            else
            {
                fail2 = destinatario_setEmail(dest,email);
                if(fail2 == -1)
                {
                    returnAux = -1;
                }


                 pList->add(pList,dest);

                returnAux = 0;

            }


        }

    }

    fclose(pFile);
    return returnAux;

}

