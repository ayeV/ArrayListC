int parserDestinatarios(FILE* pFile, ArrayList* pList,char* path);

