#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <ctype.h>
#include <string.h>
#include "ArrayList.h"
#include "input.h"
#include "cliente.h"
#include "alquiler.h"

eCliente* cliente_new(void)
{
    eCliente* newCliente = (eCliente*)malloc(sizeof(eCliente));
    newCliente->id = 0;
    newCliente->cantAlquileres = 0;
    newCliente->estado = INACTIVO;
    return newCliente;
}


/*int deleteEmployee(ArrayList* pList)
{
    int option;
    char continueDo='s';
    int indexAux;
    Employee* mostrar=NULL;
    do
    {
        system("cls");
        getInt(&option,"\n1-Dar de baja un empleado\n2-Dar de baja un empleado y mostrar datos eliminados\n3-Volver al menu principal\nOption:","",1,3);
        switch(option)
        {
        case 1:
        //este caso es recomendable si ya no necesito hacer mas nada con el dato a eliminar
            getInt(&indexAux,"ingrese el legajo del usuario a eliminar","Error usuario no existente",0,pList->size);
            pList->remove(pList,indexAux-1);
            printf("Usuario eliminado");
            break;
        case 2:
             getInt(&indexAux,"ingrese el legajo del usuario a eliminar","Error usuario no existente",0,pList->size);
            mostrar=(Employee*)pList->pop(pList,indexAux-1);
            printf("Usuario eliminado");
            employee_print(mostrar);
            system("pause");
            break;
        case 3:
            continueDo='n';
            break;
        default:
            break;

        }

    }while(continueDo!='n');
}*/

//SET ID

int cliente_setId(eCliente* this, char* id)
{
    int retorno = -1;
    int aux;
    if(this != NULL && id !=NULL)
    {
        aux = atoi(id);
        this->id = aux;
        retorno = 0;
    }


    return retorno;

}
//GET ID
int cliente_getId(eCliente* this)
{
    int retorno= -1;
    if(this != NULL)
    {
        retorno = this->id;
    }
    return retorno;

}
//SET NAME
int cliente_setNombre(eCliente* this, char* name)
{
    int returnAux = -1;
    int len;


    if(this != NULL && name != NULL)
    {

        len = strlen(name);
        if(len >50)
        {
            printf("Error\n");

        }
        else
        {

            strcpy(this->nombre, name);
        }

        returnAux = 0;

    }

    return returnAux;

}
//GET NAME
char* cliente_getNombre(eCliente* this)
{
    char* retorno;

    if(this != NULL)
    {
        retorno = this->nombre;
    }

    return retorno;


}

//SET LASTNAME
int cliente_setApellido(eCliente* this, char* lastName)
{
    int returnAux = -1;
    int len;

    if(this != NULL && lastName != NULL)
    {
        len = strlen(lastName);
        if(len>50)
        {
            printf("Error\n");
            exit(1);
        }
        else
        {
            strcpy(this->apellido, lastName);
        }


        returnAux = 0;

    }

    return returnAux;

}

//GET LASTNAME
char* cliente_getApellido(eCliente* this)
{
    char* retorno;

    if(this != NULL)
    {
        retorno = this->apellido;
    }

    return retorno;


}
//SET DNI
int cliente_setDNI(eCliente* this, int dni)
{
    int retorno = -1;

    if(this != NULL && dni >0)
    {

        this->dni = dni;
        retorno = 0;
    }


    return retorno;

}
//GET DNI
int cliente_getDNI(eCliente* this)
{
    int retorno= -1;
    if(this != NULL)
    {
        retorno = this->dni;
    }
    return retorno;

}

int cliente_setEstado(eCliente* this, char* estado)
{
    int retorno = -1;
    int aux;
    if(this != NULL && estado !=NULL)
    {
        aux = atoi(estado);
        if(aux == ACTIVO || aux ==INACTIVO)
        this->estado = aux;
        retorno = 0;
    }


    return retorno;

}
//GET ESTADO
int cliente_getEstado(eCliente* this)
{
    int retorno= -1;
    if(this != NULL)
    {
        retorno = this->estado;
    }
    return retorno;

}

int cliente_setCantidadAlquileres(eCliente* this, int cant)
{
    int retorno = -1;

    if(this != NULL && cant >0)
    {

        this->cantAlquileres = cant;
        retorno = 0;
    }


    return retorno;

}

int cliente_getCantidadAlquileres(eCliente* this)
{
    int retorno= -1;
    if(this != NULL)
    {
        retorno = this->cantAlquileres;
    }
    return retorno;

}



void cliente_print(eCliente* this)
{
    if(this !=NULL)
    {
        if(cliente_getEstado(this) == ACTIVO)
        {
            printf("ID\tNOMBRE\tAPELLIDO\tDNI\n");
            printf("%d %10s\t%10s\t%d\n",cliente_getId(this), cliente_getNombre(this), cliente_getApellido(this),cliente_getDNI(this));
        }

        else
        {
            printf("Cliente inactivo: %s\n",cliente_getNombre(this));
        }
    }

}


void clientes_print(ArrayList* this)
{
    int i;
    for(i=0;i<this->len(this);i++)
    {
         if(this->isEmpty(this) == 0){

            cliente_print(this->get(this,i));
         }

    }
}
