#ifndef CLIENTE_H_INCLUDED
#define CLIENTE_H_INCLUDED
#define ACTIVO 1
#define INACTIVO 0
#include "alquiler.h"
typedef struct
{
    int id;
    int dni;
    char nombre[51];
    char apellido[51];
    int cantAlquileres;
    int estado;

}eCliente;

eCliente* cliente_new(void);
int cliente_setId(eCliente* this, char* id);
int cliente_getId(eCliente* this);
int cliente_setNombre(eCliente* this, char* name);
char* cliente_getNombre(eCliente* this);
int cliente_setApellido(eCliente* this, char* lastName);
char* cliente_getApellido(eCliente* this);
int cliente_setDNI(eCliente* this, int dni);
int cliente_getDNI(eCliente* this);
int cliente_setEstado(eCliente* this, char* estado);
int cliente_getEstado(eCliente* this);
void cliente_print(eCliente* this);
int cliente_setCantidadAlquileres(eCliente* this, int cant);
int cliente_getCantidadAlquileres(eCliente* this);




#endif //CLIENTE_H_INCLUDED
