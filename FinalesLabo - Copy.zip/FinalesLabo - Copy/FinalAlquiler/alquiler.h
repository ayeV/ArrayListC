#ifndef ALQUILER_H_INCLUDED
#define ALQUILER_H_INCLUDED

#define FINALIZADO 0
#define ALQUILADO 1

#define AMOLADORA 1
#define MEZCLADORA 2
#define TALADRO 3


typedef struct
{
    char nombre[51];
}eOperador;

typedef struct
{
    int id;
   int idCliente;
   int equipo;
   int tiempoEstimado;
   int tiempoReal;
   eOperador operador;
   int estado;

}eAlquiler;

eAlquiler* alquiler_new();
int alquiler_setID(eAlquiler* this, char* id);
int alquiler_getID(eAlquiler *this);
int alquiler_setIDCliente(eAlquiler* this, int idCliente);
int alquiler_getIDCliente(eAlquiler *this);
int alquiler_setOperador(eAlquiler* this, char* name);
char* alquiler_getOperador(eAlquiler* this);
int alquiler_setEstado(eAlquiler* this, int estado);
int alquiler_getEstado(eAlquiler* this);
int alquiler_setEquipo(eAlquiler* this, char* equipo);
int alquiler_getEquipo(eAlquiler* this);
int alquiler_setTiempoEstimado(eAlquiler* this, char* tiempoEstimado);
int alquiler_getTiempoEstimado(eAlquiler *this);
int alquiler_setTiempoReal(eAlquiler* this, char* tiempoReal);
int alquiler_getTiempoReal(eAlquiler *this);




#endif //ALQUILER_H_INCLUDED

