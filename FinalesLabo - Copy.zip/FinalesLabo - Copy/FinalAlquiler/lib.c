#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <ctype.h>
#include "lib.h"
#include "ArrayList.h"
#include "input.h"
#include "cliente.h"
#include "alquiler.h"


void altaCliente(ArrayList* this)
{
    char name[100],lastName[100];

    int dni;
    int i;


    eCliente* client = cliente_new();

    getString(name,"Nombre: ","Error ingrese nombre valido",2,50);
    cliente_setNombre(client,name);

    getString(lastName,"Apellido: ","Error ingrese apellido valido",2,50);
    cliente_setApellido(client,lastName);

    getInt(&dni,"DNI: ","Error, ingrese DNI valido: ",1,1000);
    cliente_setDNI(client,dni);
    this->add(this,client);
    for(i=0; i<this->len(this); i++)
    {
        client->id = i+1;

    }
    client->estado = ACTIVO;

    printf("Datos del cliente agregado: \n");
    cliente_print(client);

}
int menuModificar()
{
    int opcion;

    system("cls");

    printf("1-Nombre\n");
    printf("2-Apellido\n");
    printf("3-Salir\n");
    printf("\nIndique opcion: ");
    scanf("%d", &opcion);

    return opcion;
}

eCliente* buscarPorID(int id, ArrayList* listaClientes)
{
    eCliente* client;
    eCliente* returnAux = NULL;
    int i;

    for(i=0;i<listaClientes->len(listaClientes);i++)
    {
       client = listaClientes->get(listaClientes,i);
       if( id == cliente_getId(client) && cliente_getEstado(client) == ACTIVO)
       {
           returnAux = client;
       }
    }
    return returnAux;
}


int modificarCliente(ArrayList* this)
{
    int returnAux = -1;
    char seguir = 's';
    char nombre[51], apellido[51];
    int id;

    eCliente* client;
    if(this != NULL)
    {



    getInt(&id, "Ingrese el ID del cliente a modificar: ", "Rango invalido, reingrese: ",1,1000);
    client = buscarPorID(id,this);
    if(client == NULL)
    {
        printf("Cliente no encontrado\n");
    }
    else
    {
        cliente_print(client);
        while( seguir == 's')
        {
             switch(menuModificar())
        {

        case 1:
            printf("Modificar nombre\n");
            getString(nombre,"Nuevo nombre: ", "Error, reingrese: ",2,50);
            cliente_setNombre(client,nombre);

            break;
        case 2:
            printf("Modifica apellido\n");
             getString(apellido,"Nuevo apellido: ", "Error, reingrese: ",2,50);
            cliente_setApellido(client,apellido);
            break;
        case 3:
            printf("Cliente modificado\n");
            cliente_print(client);

             seguir = 'n';
             system("pause");
            break;



        }

        }

    }


    returnAux = 0;

}

    return returnAux;
}

int bajaCliente(ArrayList* this, ArrayList* this2)
{
    int returnAux = -1;
    char confirma;
    eCliente* client;
    int id;

    if( this != NULL)
    {
        getInt(&id, "Ingrese el ID del cliente a dar de baja: ", "Rango invalido, reingrese: ",1,1000);
        client = buscarPorID(id,this);
        if(client == NULL)
        {
            printf("Cliente inexistente\n");

        }
        else
        {
            printf("Cliente a dar de baja: ");
            cliente_print(client);
            do
            {
                printf("\nConfirma la baja? [s|n]\n: ");
                fflush(stdin);
                scanf("%c", &confirma);
                confirma = tolower(confirma);
            }
            while(confirma != 's' && confirma != 'n');
            if( confirma  == 's')
            {
                this2->add(this2,client);
                printf("Cliente eliminado: \n");
                cliente_print(client);
                system("pause");

            }
            else
            {
                printf("Ha cancelado la baja\n");

            }


        }


        returnAux = 0;

    }





    return returnAux;

}

int nuevoAlquiler(ArrayList* this, ArrayList* this2)
{
    int returnAux = -1;
    int idCliente;
    int i;
    char equipo[4],tiempoEstimado[4], operador[51];
    eCliente* client;
    eAlquiler* alqui = alquiler_new();

    if(this != NULL)
    {

        getInt(&idCliente, "Ingrese el ID del cliente: ", "Rango invalido, reingrese: ",1,1000);
        client = buscarPorID(idCliente,this2);
        alquiler_setIDCliente(alqui,idCliente);
        if(client == NULL)
        {
        printf("Cliente no encontrado\n");
        }
        else

        {
            cliente_print(client);
            getString(equipo,"Ingrese el equipo a ser alquilado: ","Rango invalido, reingrese: ",1,4);
            alquiler_setEquipo(alqui,equipo);
            getString(tiempoEstimado,"Ingrese el tiempo estimado: ","Rango invalido, reingrese: ",1,4);
            alquiler_setTiempoEstimado(alqui,tiempoEstimado);
            getString(operador,"Ingrese el operador: ","Rango invalido, reingrese: ",2,50);
            alquiler_setOperador(alqui,operador);

            for(i = 0;i<=this->len(this);i++)
            {
                alqui->id = i+1;
            }
             alquiler_setEstado(alqui,ALQUILADO);
            cliente_setCantidadAlquileres(client,cliente_getCantidadAlquileres(client) + 1);
            this->add(this,alqui);
            printf("Datos del alquiler agregado\n");
            alquiler_print(alqui);

        }
        returnAux = 0;
    }
    return returnAux;
}


eAlquiler* buscarPorIDAlquiler(int id, ArrayList* listaAlquiler)
{
    eAlquiler* alqui;
    eAlquiler* returnAux = NULL;
    int i;
    if( listaAlquiler != NULL)
    {

        for(i=0; i<listaAlquiler->len(listaAlquiler); i++)
        {
            alqui = listaAlquiler->get(listaAlquiler,i);
            if( id == alquiler_getID(alqui) && alquiler_getEstado(alqui) == ALQUILADO)
            {
                returnAux = alqui;
            }
        }
    }

    return returnAux;
}

int finAlquiler( ArrayList* this, ArrayList* alquileresFinalizados)
{
    int returnAux = -1;
    int idAlquiler;

    char tiempoReal[10];
    char confirma;
    eAlquiler* alqui;

    if(this != NULL)
    {
         getInt(&idAlquiler, "Ingrese el ID del alquiler a finalizar: ", "Rango invalido, reingrese: ",1,1000);
         alqui = buscarPorIDAlquiler(idAlquiler,this);

         if(alqui == NULL)
         {
             printf("Alquiler inexistente\n");
         }
         else
         {
             alquiler_print(alqui);
            do
            {
                printf("\nConfirma la baja? [s|n]\n: ");
                fflush(stdin);
                scanf("%c", &confirma);
                confirma = tolower(confirma);
            }
            while(confirma != 's' && confirma != 'n');
            if( confirma  == 's')
            {
                getString(tiempoReal,"Tiempo real: ","Error, reingrese: ",2,10);
               alquiler_setTiempoReal(alqui,tiempoReal);
               alquiler_setEstado(alqui,FINALIZADO);
                alquileresFinalizados->add(alquileresFinalizados,alqui);
                printf("Alquiler finalizado: \n");

                system("pause");

            }
            else
            {
                printf("Ha cancelado la operacion\n");

            }
         }

        returnAux = 0;

    }
    return returnAux;
}

int searchMayorCantAlquileres(ArrayList*  listaAlquileres)
{
    int max =0;
    int i;
    int returnAux = -1;
    int flag = 0;
    int contAmoladora = 0;
    int contMezcladora = 0;
    int contTaladro = 0;
    eAlquiler* alqui  = NULL;
    if(listaAlquileres != NULL){

    for(i= 0; i<listaAlquileres->len(listaAlquileres); i++)
    {
        listaAlquileres->get(listaAlquileres,i);
        if(alquiler_getEquipo(alqui) ==  AMOLADORA)
        {
            contAmoladora++;
        }
        else if( alquiler_getEquipo(alqui)== TALADRO)
        {
            contTaladro++;
        }
        else if(alquiler_getEquipo(alqui)== MEZCLADORA)
        {
            contMezcladora++;
        }


    }
    if((contAmoladora > contTaladro && contAmoladora > contMezcladora) || flag == 0)
    {
        max = contAmoladora;
        flag = 1;


        }
        else if((contTaladro > contAmoladora && contTaladro > contMezcladora) || flag == 0)
        {
            max = contTaladro;
            flag= 1;
        }
        else if((contMezcladora > contAmoladora && contMezcladora > contTaladro) || flag == 0)
        {
            max = contMezcladora;
            flag = 1;
        }
        returnAux = max;

    }
    return returnAux;


}

int searchMayorCantidadDeAlquileresDeEquipo(ArrayList *listaClientes)
{
    int returnAux = -1;
    eCliente *client = NULL;
    int max = 0;
    int i;
    int flag = 0;

    if(listaClientes != NULL)
    {

        for(i=0;i<listaClientes->len(listaClientes); i++)
        {
            listaClientes->get(listaClientes,i);
            if(cliente_getCantidadAlquileres(client) > max || flag == 0)
            {
                max = cliente_getCantidadAlquileres(client);
                flag = 1;
            }



        }
        returnAux = max;

    }

    return returnAux;
}

int tiempoPromedioAlquiler(ArrayList* listaAlquileresFinalizados)
{
    int returnAux = -1;
    int tiempo = 0;
    int tiempoPromedio = 0;
    int i;
    if(listaAlquileresFinalizados != NULL)
    {
        for(i= 0;i <listaAlquileresFinalizados->len(listaAlquileresFinalizados); i++)
        {
            tiempo = tiempo + alquiler_getTiempoReal(listaAlquileresFinalizados->get(listaAlquileresFinalizados,i));


        }
        if( i != 0)
        {
            tiempoPromedio = tiempo/i;
        }
        returnAux = tiempoPromedio;
    }


    return returnAux;


}

int menuListar()
{
    int opcion;

    system("cls");

    printf("1-El nombre y apellido del asociado con mas alquileres\n");
    printf("2-El o los equipos/s mas alquilado/s y su cantidad\n");
    printf("3-El tiempo promedio real de alquiler de los equipos\n");
    printf("4-Salir\n");
    printf("\nIndique opcion: ");
    scanf("%d", &opcion);

    return opcion;
}

void informar(ArrayList* listaClientes, ArrayList* listaAlquileres, ArrayList *listaAlquileresFinalizados)
{

    int salir = 1;
    int mayorCantidadAlquileres = searchMayorCantAlquileres(listaAlquileres);
    int mayorCantidadAlquileresEquipos = searchMayorCantidadDeAlquileresDeEquipo(listaClientes);
   int promedio = tiempoPromedioAlquiler(listaAlquileresFinalizados);

    if( listaAlquileres !=NULL && listaAlquileres != NULL && listaAlquileresFinalizados != NULL)
    {
        do
        {
            switch(menuListar())
            {
            case 1:

                printf("Cant mayor de alquileres: %d\n", mayorCantidadAlquileres);
                int i;
                for(i= 0; i<listaClientes->len(listaClientes);i++)
                {
                    cliente_print(listaClientes->get(listaClientes,i));
                }

                break;
            case 2:




                break;
            case 3:
                    printf("Promedio de tiempo real: %d\n", promedio);
                    system("pause");
                break;

            case 4:

                salir = 1;
                break;
            default:
                printf("Ingrese una opcion correcta [1-4]");
                break;
            }
        }
        while(salir != 1);


    }



}










