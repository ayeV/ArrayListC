#ifndef LIB_H_INCLUDED
#define LIB_H_INCLUDED



#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <ctype.h>

#include "ArrayList.h"
#include "input.h"
#include "cliente.h"
#include "alquiler.h"

void altaCliente(ArrayList* this);
int searchMayorCantidadDeAlquileresDeEquipo(ArrayList *listaClientes);
int searchMayorCantAlquileres(ArrayList*  listaAlquileres);


int tiempoPromedioAlquiler(ArrayList* listaAlquileresFinalizados);

#endif //LIB_H_INCLUDED
