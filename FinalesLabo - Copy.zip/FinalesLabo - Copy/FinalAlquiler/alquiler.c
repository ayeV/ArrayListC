#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <ctype.h>
#include <string.h>
#include "ArrayList.h"
#include "input.h"
#include "cliente.h"
#include "alquiler.h"



eAlquiler* alquiler_new()
{
    eAlquiler* newAlquiler = (eAlquiler*)malloc(sizeof(eAlquiler));
    newAlquiler->id = 0;
    newAlquiler->estado = -1;
    newAlquiler->equipo = 0;
    newAlquiler->idCliente = 0;
    newAlquiler->tiempoEstimado = 0;
    newAlquiler->tiempoReal = 0;

    return newAlquiler;


}


int alquiler_setID(eAlquiler* this, char* id)
{
    int returnAux = -1;
    int aux;

    if(this != NULL && id != NULL)
    {
        aux = atoi(id);
        this->id = aux;
        returnAux = 0;
    }
    return returnAux;

}

int alquiler_getID(eAlquiler *this)
{
    int returnAux = -1;

    if( this != NULL)
    {
        returnAux =  this->id;
    }
    return returnAux;
}

int alquiler_setIDCliente(eAlquiler* this, int idCliente)
{
    int returnAux = -1;

    if(this != NULL && idCliente >0)
    {

        this->idCliente = idCliente;
        returnAux = 0;
    }
    return returnAux;

}

int alquiler_getIDCliente(eAlquiler *this)
{
    int returnAux = -1;

    if( this != NULL)
    {
        returnAux=  this->idCliente;

    }
    return returnAux;
}

int alquiler_setOperador(eAlquiler* this, char* name)
{
    int returnAux = -1;
     int len;


    if(this != NULL && name != NULL)
    {

        len = strlen(name);
        if(len >50)
        {
            printf("Error\n");

        }
        else
        {

            strcpy(this->operador.nombre, name);
        }

        returnAux = 0;

    }

    return returnAux;

}

char* alquiler_getOperador(eAlquiler* this)
{
    char* returnAux;

    if(this != NULL)
    {
        returnAux = this->operador.nombre;
    }

    return returnAux;


}
int alquiler_setEstado(eAlquiler* this, int estado)
{
    int returnAux = -1;

    if(this != NULL && (estado == ALQUILADO || estado == FINALIZADO))
    {

        this->estado = estado;
        returnAux = 0;
    }


    return returnAux;

}
//GET ESTADO
int alquiler_getEstado(eAlquiler* this)
{
    int returnAux= -1;
    if(this != NULL)
    {
        returnAux = this->estado;
    }
    return returnAux;

}

int alquiler_setEquipo(eAlquiler* this, char* equipo)
{
    int returnAux = -1;
    int auxEquipo;
    if(this != NULL &&  equipo != NULL)
    {
        auxEquipo = atoi(equipo);
        if(auxEquipo == AMOLADORA || auxEquipo == MEZCLADORA || auxEquipo == TALADRO)
        {
            this->equipo = auxEquipo;
            returnAux = 0;
        }

    }

    return returnAux;
}

int alquiler_getEquipo(eAlquiler* this)
{
    int returnAux = -1;
    if(this != NULL)
    {
        returnAux = this->equipo;
    }
    return returnAux;

}


int alquiler_setTiempoEstimado(eAlquiler* this, char* tiempoEstimado)
{
    int returnAux = -1;
    int aux;

    if(this != NULL && tiempoEstimado != NULL)
    {
        aux = atoi(tiempoEstimado);
        this->tiempoEstimado = aux;
        returnAux = 0;
    }
    return returnAux;

}

int alquiler_getTiempoEstimado(eAlquiler *this)
{
    int returnAux = -1;

    if( this != NULL)
    {
        returnAux=  this->tiempoEstimado;

    }
    return returnAux;
}

int alquiler_setTiempoReal(eAlquiler* this, char* tiempoReal)
{
    int returnAux = -1;
    int aux;

    if(this != NULL && tiempoReal != NULL)
    {
        aux = atoi(tiempoReal);
        this->tiempoReal = aux;
        returnAux = 0;
    }
    return returnAux;

}

int alquiler_getTiempoReal(eAlquiler *this)
{
    int returnAux = -1;

    if( this != NULL)
    {
        returnAux =  this->tiempoReal;

    }
    return returnAux;
}




void alquiler_print(eAlquiler* this){
    printf("--------------------------------\n");
    printf("ALQUILER ID =    %d \n", alquiler_getID(this));
    printf("CLIENTE ID =     %d \n", alquiler_getIDCliente(this));
    printf("Operador:        %s \n", alquiler_getOperador(this));
    printf("Tiempo Estimado: %d \n", alquiler_getTiempoEstimado(this));
    printf("Tiempo Real:     %d \n", alquiler_getTiempoReal(this));

    if(alquiler_getEquipo(this) == AMOLADORA)
        printf("Equipo:          Amoladora \n");
    else if(alquiler_getEquipo(this) == TALADRO)
        printf("Equipo:          Taladro \n");
    else
        printf("Equipo:          Mezcladora \n");

    if(alquiler_getEstado(this) == ALQUILADO)
        printf("Estado:          Alquilado \n");
    else
        printf("Estado:          Finalizado \n");

    printf("--------------------------------\n");
}
