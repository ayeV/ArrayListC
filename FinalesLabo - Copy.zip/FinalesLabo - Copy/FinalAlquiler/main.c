#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <ctype.h>

#include "ArrayList.h"
#include "input.h"
#include "cliente.h"
#include "alquiler.h"
#include "lib.h"


int main()
{
    int opcion = 0;
    char seguir = 's';



    ArrayList *listaClientes;
    ArrayList *listaClientesInactivos;
    ArrayList *listaAlquileres;
    ArrayList *listaAlquileresFinalizados;



    listaClientes = al_newArrayList();
    listaClientesInactivos = al_newArrayList();
    listaAlquileres = al_newArrayList();
    listaAlquileresFinalizados = al_newArrayList();

    while(seguir=='s')
    {
        printf("1-Agregar cliente\n");
        printf("2-Modificar cliente\n");

        printf("3-Baja de un cliente\n");
        printf("4-Ver clientes\n");
        printf("5-Nuevo alquiler\n");
        printf("6-Fin de alquiler\n");
        printf("7-Informar\n");
        printf("8- Salir\n");

        scanf("%d",&opcion);


        switch(opcion)
        {
        case 1:
            printf("ALTA CLIENTE\n");
            altaCliente(listaClientes);

            system("pause");

            break;
        case 2:

            printf("--MODIFICAR CLIENTE--\n");

            if(modificarCliente(listaClientes) == 0)
            {
                printf("Operacion exitosa\n");
            }



            system("pause");
            break;
        case 3:
            printf("--BAJA DE UN CLIENTE--\n");
            if(bajaCliente(listaClientes,listaClientesInactivos) == -1)
            {
                printf("Error\n");
            }


            system("pause");
            break;
        case 4:
            printf("Lista de clientes\n");
            clientes_print(listaClientes);

            system("pause");
            break;
        case 5:
            printf(" 1-AMOLADORA 2-MEZCLADORA 3-TALADRO\n");
            if(nuevoAlquiler(listaAlquileres, listaClientes) == -1)
            {
                printf("Se produjo un error\n");
            }

            system("pause");

            break;
        case 6:
            if(finAlquiler(listaAlquileres,listaAlquileresFinalizados) == -1)
            {
                printf("error\n");
            }

            system("pause");
            break;
        case 7:
            informar(listaClientes,listaAlquileres,listaAlquileresFinalizados);
            break;


        case 8:


            seguir = 'n';
            system("pause");
            break;
        default:
            printf("Opcion invalida\n");
            system("pause");
            break;
        }
    }

    return 0;
}
