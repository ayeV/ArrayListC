#ifndef SERVICES_H_INCLUDED
#define SERVICES_H_INCLUDED


typedef struct
{
    int id;
    char name[33];
    char email[65];
}eService;





#endif // SERVICES_H_INCLUDED
