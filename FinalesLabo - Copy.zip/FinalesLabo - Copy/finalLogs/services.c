#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <ctype.h>
#include <string.h>
#include "ArrayList.h"
#include "services.h"
#include "log.h"

 int contFallos = 0;
    int menorA3 = 0;
    int igualA3 = 0;
    int entre4y7 = 0;
    int mayorA7=0;
    int servConMasFallos = 0;


eService* service_new(void)
{
    eService* returnAux = (eService*)malloc(sizeof(eService));

    return returnAux;
}

int service_setId(eService* this, char* id)
{
    int retorno = -1;
    int aux;
    if(this != NULL && id !=NULL)
    {
        aux = atoi(id);
        this->id = aux;
        retorno = 0;
    }


    return retorno;

}

int service_getId(eService* this)
{
    int retorno= -1;
    if(this != NULL)
    {
        retorno = this->id;
    }
    return retorno;

}

int service_setName(eService* this, char* name)
{
    int returnAux = -1;
    int len;


    if(this != NULL && name != NULL)
    {

        len = strlen(name);
        if(len >32)
        {
            printf("Error\n");

        }
        else
        {

            strcpy(this->name, name);
        }

        returnAux = 0;

    }

    return returnAux;

}

char* service_getName(eService* this)
{
    char* retorno;

    if(this != NULL)
    {
        retorno = this->name;
    }

    return retorno;


}

int service_setEmail(eService* this, char* email)
{
    int returnAux = -1;
    int len;


    if(this != NULL && email!= NULL)
    {

        len = strlen(email);
        if(len >64)
        {
            printf("Error\n");

        }
        else
        {

            strcpy(this->email, email);
        }

        returnAux = 0;

    }

    return returnAux;

}

char* service_getEmail(eService* this)
{
    char* retorno;

    if(this != NULL)
    {
        retorno = this->email;
    }

    return retorno;


}

void service_print(eService* serv)
{
    if(serv != NULL)
    {
        printf("ID: %d\nName: %s\nEmail:  %.30s\n\n",service_getId(serv),service_getName(serv),service_getEmail(serv));
    }
}

void service_printAll(ArrayList *this)
{
    int i;
    if(this != NULL)
    {
        for(i= 0;i<this->len(this);i++)
        {
            service_print(this->get(this,i));
        }
    }
}

eService* buscarID(int id, ArrayList *listaServices)
{
    eService* serv;
    eService* returnAux  = NULL;
    int i;
    for(i=0;i<listaServices->len(listaServices);i++)
    {
        serv = listaServices->get(listaServices,i);
        if(service_getId(serv) == id )
        {
            returnAux = serv;
            break;
        }
    }
    return returnAux;

}


void procesarInfo(ArrayList* listaLogs, ArrayList* listaServices)
{
    int i;

    FILE *pFile1;
    FILE *pFile2;
    int gravedad;
    eLog* log = log_new();
    eService* serv = service_new();
    if(listaLogs != NULL)
    {
        for(i=0; i<listaLogs->len(listaLogs); i++)
        {
            log = listaLogs->get(listaLogs,i);
            gravedad = log_getGravedad(log);
            serv = buscarID(log_getServiceId(log),listaServices);
            if(gravedad <3)
            {
                menorA3++;
            }
            else if(gravedad == 3)
            {
                pFile1 = fopen("warnings.txt","a");
                if(pFile1 == NULL)
                {
                    printf("Error al crear el archivo warnings\n");
                }
                fprintf(pFile1,"%s,%s,%s,%s,%s\n",log_getDate(log),log_getTime(log),service_getName(serv),log_getMsg(log),service_getEmail(serv));
                fclose(pFile1);
                igualA3++;
            }
            else if(gravedad > 4 && gravedad<=7)
            {
                printf("Fecha: %s\nHora: %s\nNombre: %s\nMensaje: %s\nEmail: %s\n",log_getDate(log),log_getTime(log),service_getName(serv),log_getMsg(log),service_getEmail(serv));
                entre4y7++;

            }
            else if(gravedad > 7)
            {
                pFile2 = fopen("errors.txt","a");
                if(pFile2 == NULL)
                {
                    printf("Error a crear el archivo errors\n");
                }
                fprintf(pFile2,"%s,%s,%s,%s,%s\n",log_getDate(log),log_getTime(log),service_getName(serv),log_getMsg(log),service_getEmail(serv));
                fclose(pFile2);
                mayorA7++;

            }
        }
    }


}



char* buscarServidorConMasFallos(ArrayList *listaLogs, ArrayList *listaServices)
{
     eLog *auxLog;
    eService *auxService;
     char *nombreServicioMasFallos;
    int i,j;
    for(i=0;i<listaServices->len(listaServices);i++ )
    {
       auxService = listaServices->get(listaServices,i);
       contFallos = 0;
        for(j=0;j<listaLogs->len(listaLogs);j++)
        {

              auxLog = listaLogs->get(listaLogs,j);
              if(auxService->id+i == auxLog->serviceId+j)
              {
                  contFallos++;
              }
        }

        if(i==0)
        {
            servConMasFallos = contFallos;
            nombreServicioMasFallos = auxService->name;

        }
        else if(contFallos>servConMasFallos)
        {
            servConMasFallos = contFallos;
            nombreServicioMasFallos = auxService->name;
        }

    }
    return nombreServicioMasFallos;


}

void mostrarEstadisticas(ArrayList* listaLogs, ArrayList* listaServices)
{
    printf("-----CANT FALLOS SEGUN GRAVEDAD-----\n");
    printf("Menores a 3: %d\n",menorA3);
    printf("Iguales a 3: %d\n",igualA3);
    printf("Entre 4 y 7: %d\n",entre4y7);
    printf("Mayores a 7: %d\n",mayorA7);
    printf("\n\n");

    char* servMax;
    servMax = buscarServidorConMasFallos(listaLogs,listaServices);
    printf("Servicio con mas fallos: %s\n", servMax);



}
