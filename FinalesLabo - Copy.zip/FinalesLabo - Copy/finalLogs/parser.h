int parserLogs(ArrayList* this);
int parserServices(ArrayList* this);

