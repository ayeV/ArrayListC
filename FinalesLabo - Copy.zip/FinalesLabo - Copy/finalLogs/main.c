#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <ctype.h>

#include "ArrayList.h"
#include "log.h"
#include "services.h"
#include "parser.h"


int main()
{
    int opcion = 0;
    char seguir = 's';

    ArrayList* listaLogs;
    listaLogs =  al_newArrayList();
    ArrayList* listaServices;
    listaServices = al_newArrayList();


    while(seguir=='s')
    {
        printf("1-Leer log y services\n");
        printf("2-Procesar informacion\n");
        printf("3-Mostrar estadisticas\n");
        printf("4- Salir\n");

        scanf("%d",&opcion);


        switch(opcion)
        {
        case 1:
            if(parserLogs(listaLogs) == -1)
            {
                printf("error\n");
            }
            log_printAll(listaLogs);
            system("pause");
            if(parserServices(listaServices)== -1)
            {
                printf("error\n");
            }

            printf(" ---SERVICES---\n");
            service_printAll(listaServices);
            break;
        case 2:
            procesarInfo(listaLogs,listaServices);

            break;
        case 3:
            mostrarEstadisticas(listaLogs,listaServices);

            break;
        case 4:
            seguir = 'n';
            system("pause");
            break;
        default:
            printf("Opcion invalida\n");
            system("pause");
            break;
        }
    }

    return 0;
}
