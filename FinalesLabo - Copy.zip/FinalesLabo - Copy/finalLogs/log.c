#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <ctype.h>
#include <string.h>
#include "ArrayList.h"
#include "log.h"


eLog* log_new(void)
{
    eLog* returnAux = (eLog*)malloc(sizeof(eLog));

    return returnAux;
}

int log_setServiceId(eLog* this, char* id)
{
    int retorno = -1;
    int aux;
    if(this != NULL && id !=NULL)
    {
        aux = atoi(id);
        this->serviceId = aux;
        retorno = 0;
    }


    return retorno;

}

int log_getServiceId(eLog* this)
{
    int retorno= -1;
    if(this != NULL)
    {
        retorno = this->serviceId;
    }
    return retorno;

}

int log_setDate(eLog* this, char* date)
{
    int returnAux = -1;
    int len;


    if(this != NULL && date != NULL)
    {

        len = strlen(date);
        if(len >10)
        {
            printf("Error\n");

        }
        else
        {

            strcpy(this->date, date);
        }

        returnAux = 0;

    }

    return returnAux;

}

char* log_getDate(eLog* this)
{
    char* retorno;

    if(this != NULL)
    {
        retorno = this->date;
    }

    return retorno;


}

int log_setTime(eLog* this, char* time)
{
    int returnAux = -1;
    int len;


    if(this != NULL && time != NULL)
    {

        len = strlen(time);
        if(len >5)
        {
            printf("Error\n");

        }
        else
        {

            strcpy(this->time, time);
        }

        returnAux = 0;

    }

    return returnAux;

}

char* log_getTime(eLog* this)
{
    char* retorno;

    if(this != NULL)
    {
        retorno = this->time;
    }

    return retorno;


}

int log_setGravedad(eLog* this, char* gravedad)
{
    int retorno = -1;
    int aux;
    if(this != NULL && gravedad !=NULL)
    {
        aux = atoi(gravedad);
        this->gravedad = aux;
        retorno = 0;
    }


    return retorno;

}

int log_getGravedad(eLog* this)
{
    int retorno= -1;
    if(this != NULL)
    {
        retorno = this->gravedad;
    }
    return retorno;

}


int log_setMsg(eLog* this, char* msg)
{
    int returnAux = -1;
    int len;


    if(this != NULL && msg != NULL)
    {

        len = strlen(msg);
        if(len >64)
        {
            printf("Error\n");

        }
        else
        {

            strcpy(this->msg, msg);
        }

        returnAux = 0;

    }

    return returnAux;

}

char* log_getMsg(eLog* this)
{
    char* retorno;

    if(this != NULL)
    {
        retorno = this->msg;
    }

    return retorno;


}

void log_print(eLog* log)
{
    if(log != NULL)
    {
        printf("Date: %s\nTime: %s\nServiceId: %d\nGravedad: %d\nMsg: %.30s\n\n",log_getDate(log),log_getTime(log),
               log_getServiceId(log),log_getGravedad(log),log_getMsg(log));
    }
}


void log_printAll(ArrayList *this)
{
    int i;
    for(i=0; i<this->len(this); i++)
    {

        log_print(this->get(this,i));

    }
}
