#include <stdio.h>
#include <stdlib.h>
#include "string.h"
#include "ArrayList.h"
#include "log.h"
#include "services.h"

int parserLogs( ArrayList* this)
{
    char date[128],time[128],id[128],gravedad[128],msg[128];

    eLog *log;
    FILE *pFile;
    int cant;
    int returnAux = -1;

    if(this != NULL)
    {
        pFile = fopen("log.txt","r");
        if(pFile == NULL)
        {
            printf("Error, no se puede abrir el archivo\n");
        }



        while( !feof(pFile))
        {
            cant =   fscanf(pFile,"%[^;];%[^;];%[^;];%[^;];%[^\n]\n",date,time,id,gravedad,msg);


            if(cant != 5)
            {
                if(feof(pFile))
                {
                    break;
                }
                else
                {
                    printf("No se pudo leer el ultimo registro\n");
                    break;
                }
            }
                log = log_new();
                log_setDate(log,date);
                log_setTime(log,time);
                log_setServiceId(log,id);
                log_setGravedad(log,gravedad);
                log_setMsg(log,msg);


                 this->add(this,log);

                returnAux = 0;

            }


        }

    fclose(pFile);
    return returnAux;
}


int parserServices(ArrayList* this)
{
    char id[128],name[128],email[128];

    eService *serv;
    FILE *pFile;
    int cant;
    int returnAux = -1;

    if(this != NULL)
    {
        pFile = fopen("services.txt","r");
        if(pFile == NULL)
        {
            printf("Error, no se puede abrir el archivo\n");
        }



        while( !feof(pFile))
        {
            cant =   fscanf(pFile,"%[^;];%[^;];%[^\n]\n",id,name,email);


            if(cant != 3)
            {
                if(feof(pFile))
                {
                    break;
                }
                else
                {
                    printf("No se pudo leer el ultimo registro\n");
                    break;
                }
            }
                serv = service_new();
                service_setId(serv,id);
                service_setEmail(serv,email);
                service_setName(serv,name);

                 this->add(this,serv);

                returnAux = 0;

            }


        }

    fclose(pFile);
    return returnAux;
}





