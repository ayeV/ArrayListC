#ifndef LOG_H_INCLUDED
#define LOG_H_INCLUDED

typedef struct
{

    char date[11];
    char time[6];
    int serviceId;
    int gravedad;
    char msg[65];


}eLog;

eLog* log_new(void);
char* log_getDate(eLog* this);
int log_setServiceId(eLog* this, char* id);
int log_getServiceId(eLog* this);
int log_setDate(eLog* this, char* date);
int log_setTime(eLog* this, char* time);
char* log_getTime(eLog* this);
int log_setGravedad(eLog* this, char* gravedad);
int log_getGravedad(eLog* this);
int log_setMsg(eLog* this, char* msg);
char* log_getMsg(eLog* this);
void log_print(eLog* log);
void log_printAll(ArrayList *this);



#endif // LOG_H_INCLUDED
